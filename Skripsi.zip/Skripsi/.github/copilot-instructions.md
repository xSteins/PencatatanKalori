Proyek: \textit{Template} Skripsi FTIS UNPAR

Tujuan
- Membantu agen \textit{AI} memahami struktur dan kebiasaan khusus \textit{repository} ini sebelum melakukan modifikasi.

Gambaran Umum
- `skripsi.tex` menjadi titik masuk tunggal; berkas ini memanggil `data.tex`, `dosen.tex`, seluruh paket pada `.sty/`, setiap bab `Bab/bab*.tex`, serta lampiran di `Lampiran/`.
- `data.tex` menyimpan seluruh \textit{metadata} yang dapat diubah (nama penulis, \texttt{NPM}, pengaturan `\mode{...}`, `\ttd{...}`, `\ttddosen{...}`) sehingga pengubahan identitas selalu dilakukan di sana.
- `dosen.tex` menjaga daftar nama dan gelar pejabat fakultas yang dipakai makro di `skripsi.tex`.
- `referensi.bib` menyimpan pustaka BibTeX yang akan diproses menggunakan gaya `compj.bst` di `.sty/`.
- Folder `Gambar/` menjadi lokasi standar semua ilustrasi; `\graphicspath` sudah diarahkan sehingga cukup memakai `\includegraphics{Nama-Gambar}`.
- Direktori `.sty/` menampung paket kustom (misalnya `digsig.sty`) serta berkas gaya sitasi `compj.bst`.

Kebiasaan Penting
- Hindari menyunting `skripsi.tex` kecuali benar-benar memahami alur internal; seluruh penyesuaian pengguna sebaiknya ditempatkan di `data.tex` sebagaimana ditekankan pada `READ_ME_FIRST_v13-1_!!!!!!.txt`.
- Pengaturan mode \textit{output} (`\mode{bimbingan|sidang|sidangakhir|final}`) ditetapkan di `data.tex`; contoh konfigurasi pengembangan tersedia pada blok `\toggletrue{develop}` di `skripsi.tex`.
- Daftar kode menggunakan paket `listings` dengan definisi bahasa \textit{Kotlin} kustom dan font \textit{Bera Mono}; setiap \textit{listing} wajib mempertahankan `frame=single` serta `frameround={tttt}`.
- Penyertaan tanda tangan digital memakai `digsig.sty`; aktifkan melalui `\ttd{digital}` dan atur kehadiran tanda tangan dosen dengan `\ttddosen{yes|no}` sesuai logika pada bagian Lembar Pengesahan.
- Saat menambahkan istilah berbahasa asing, pastikan setiap kata dibiarkan dalam italic melalui `\textit{...}` atau makro pada `data.tex` agar konsisten dengan kaidah penulisan.

Prosedur Kompilasi (\textit{Windows PowerShell})
- Jalankan siklus standar `pdflatex` \textrightarrow{} `bibtex` \textrightarrow{} `pdflatex` \textrightarrow{} `pdflatex` terhadap `skripsi.tex` untuk menghasilkan berkas \textit{PDF}.

```
pdflatex -interaction=nonstopmode -halt-on-error skripsi.tex ;
bibtex skripsi ;
pdflatex -interaction=nonstopmode -halt-on-error skripsi.tex ;
pdflatex -interaction=nonstopmode -halt-on-error skripsi.tex
```

- Bila tersedia, gunakan `latexmk -pdf -pdflatex="pdflatex -interaction=nonstopmode -halt-on-error" skripsi.tex` untuk kompilasi ulang otomatis.
- Unggah seluruh folder ke \textit{Overleaf} apabila kompilasi daring lebih sesuai dengan alur kerja pembimbing.

Lokasi Kritis untuk Penyesuaian
- `data.tex` menangani \textit{metadata} penulis, daftar bab melalui `\bab{...}`, lampiran via `\lampiran{...}`, serta penanda daftar gambar/tabel/kode.
- `dosen.tex` menjadi sumber tunggal nama kaprodi, pembimbing, dan penguji; pembaruan gelar harus dilakukan di sini.
- `Bab/` memuat isi setiap bab; pastikan penomoran bab selaras dengan konfigurasi `\bab{...}`.
- `.sty/` berisi paket kustom dan gaya sitasi; jangan mengubah `compj.bst` tanpa pengetahuan gaya kutipan.
- `referensi.bib` menyimpan entri pustaka; setelah menambah entri wajib menjalankan ulang `bibtex`.

Contoh Praktik
- Ubah nama penulis dengan `\namanpm{Nama Lengkap}{1999999999}` di `data.tex` agar \textit{metadata} dan `\hypersetup` diperbarui otomatis.
- Untuk pratinjau, aktifkan blok `\toggletrue{develop}` di `skripsi.tex`, namun kembalikan ke keadaan semula sebelum rilis.
- Tambahkan bab baru (misalnya `Bab/bab6.tex`) lalu sesuaikan daftar bab di `data.tex` menggunakan `\bab{1,2,3,4,5,6}` atau `\bab{all}`.

Batasan Penting
- Jangan memindah atau menghapus `.sty/compj.bst`; dependensi BibTeX akan gagal.
- Pertahankan pengaturan `\graphicspath` dan pola `\includegraphics{...}` agar pemanggilan gambar di seluruh bab tetap konsisten.
- Ikuti pola penanda `\toggletrue{...}` dan makro bawaan lain; penambahan penanda baru harus melalui diskusi dengan pemelihara.
- Saat menulis perintah baru, gunakan sintaks \LaTeX{} yang sudah tersedia melalui paket bawaan `skripsi.tex`; hindari memanggil paket tambahan tanpa konfirmasi.

Pedoman istilah Bahasa Asing
- Setiap istilah \textit{Inggris} yang tidak diterjemahkan wajib ditulis dengan `\textit{...}` atau makro serupa yang sudah didefinisikan.
- Sebelum menambah istilah baru, periksa `data.tex` mulai baris 324 untuk melihat apakah makro sudah tersedia; bila istilah muncul lebih dari empat kali dan belum ada makronya, ajukan penambahan makro baru di lokasi tersebut.

Langkah Saat Terjadi Galat
- Tinjau berkas `.log` hasil `pdflatex` pada akar proyek untuk mencari peringatan \textit{missing file} atau kesalahan sintaks makro.
- Bila sitasi gagal, pastikan `compj.bst` tetap berada di `.sty/` dan jalankan kembali `bibtex skripsi` setelah kompilasi pertama.
