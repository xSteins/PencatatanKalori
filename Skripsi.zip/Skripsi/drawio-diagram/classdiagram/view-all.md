---
config:
  layout: elk
---
classDiagram
    class OverviewScreen {
        <<Composable>>
        +OverviewScreen()
        -CircularProgressCard(Composable)
        -CalorieInfoCard(Composable)
        -TodayActivityCard(Composable)
        -RemainingCalorieCard(Composable)
    }
    class History {
        <<Composable>>
        +History()
        -ActivityHistoryCard(Composable)
        -DatePickerComponent(Composable)
    }
    class ProfileSettings {
        <<Composable>>
        +ProfileSettings()
        -UserProfileCard(Composable)
        -CalorieSettingsCard(Composable)
        -DebugOptionsCard(Composable)
    }
    class AddOrEditLogModal {
        <<Composable>>
        +AddOrEditLogModal()
        -ActivityTypeSelection(Composable)
        -CalorieInput(Composable)
        -ImagePicker(Composable)
    }
    class CalorieSettingsDialog {
        <<Composable>>
        +CalorieSettingsDialog()
        -StrategySelector(Composable)
        -GranularitySlider(Composable)
        -AdvancedModeToggle(Composable)
    }
    class CreateNewActivityDate {
        <<Composable>>
        +CreateNewActivityDate()
        -DateSelection(Composable)
        -ConfirmationDialog(Composable)
    }
    class EditUserDataDialog {
        <<Composable>>
        +EditUserDataDialog()
        -PhysicalInfoForm(Composable)
        -ActivityLevelSelector(Composable)
        -GoalTypeSelector(Composable)
    }
    class ExpandableFAB {
        <<Composable>>
        +ExpandableFAB()
        -FABItem(Composable)
        -AnimatedVisibility(Composable)
    }
    class HistoryDatePicker {
        <<Composable>>
        +HistoryDatePicker()
        -CalendarView(Composable)
        -DateNavigation(Composable)
    }
    class LogsDetailedModal {
        <<Composable>>
        +LogsDetailedModal()
        -ActivityDetails(Composable)
        -EditOptions(Composable)
        -DeleteConfirmation(Composable)
    }
    class OnboardingDialog {
        <<Composable>>
        +OnboardingDialog()
        -WelcomeStep(Composable)
        -UserDataInputStep(Composable)
        -SetupCompleteStep(Composable)
    }
    class PhysicalInfoText {
        <<Composable>>
        +PhysicalInfoText()
        -InfoDisplay(Composable)
        -EditButton(Composable)
    }
    class UserDataDebugDialog {
        <<Composable>>
        +UserDataDebugDialog()
        -DummyDataToggle(Composable)
        -DatabaseOperations(Composable)
    }
    class Screen {
        <<sealed class>>
        +String route
        Onboarding
        Overview
        History
        ProfileSettings
    }
    class NavItem {
        +String name
        +String route
        +ImageVector icon
    }
    class BottomNavBar {
        <<Composable>>
        +BottomNavBar(NavController)
        -NavigationBarItem(Composable)
    }
    class NavGraph {
        <<Composable>>
        +NavGraph(NavHostController, Modifier, String)
        -composable(Composable)
    }
    class Color {
        <<object>>
        +primaryLight Color
        +onPrimaryLight Color
        +primaryContainerLight Color
        +secondaryLight Color
        +tertiaryLight Color
        +primaryDark Color
        +onPrimaryDark Color
        +backgroundLight Color
        +backgroundDark Color
    }
    class Theme {
        <<Composable>>
        +PencatatanKaloriTheme(Boolean, Boolean, Composable)
        -lightColorScheme ColorScheme
        -darkColorScheme ColorScheme
    }
    class Type {
        <<object>>
        +Typography Typography
        -displayLarge TextStyle
        -displayMedium TextStyle
        -headlineLarge TextStyle
        -bodyLarge TextStyle
    }
    OverviewScreen --> AddOrEditLogModal : menggunakan
    OverviewScreen --> CalorieSettingsDialog : menggunakan
    OverviewScreen --> LogsDetailedModal : menggunakan
    OverviewScreen --> ExpandableFAB : menggunakan
    History --> HistoryDatePicker : menggunakan
    History --> LogsDetailedModal : menggunakan
    History --> AddOrEditLogModal : menggunakan
    ProfileSettings --> EditUserDataDialog : menggunakan
    ProfileSettings --> CalorieSettingsDialog : menggunakan
    ProfileSettings --> UserDataDebugDialog : menggunakan
    ProfileSettings --> PhysicalInfoText : menggunakan
    ProfileSettings --> CreateNewActivityDate : menggunakan
    NavGraph --> Screen : menggunakan rute
    NavGraph --> OverviewScreen : memasang
    NavGraph --> History : memasang
    NavGraph --> ProfileSettings : memasang
    BottomNavBar --> NavItem : menggunakan
    BottomNavBar --> Screen : navigasi ke
    Theme --> Color : menggunakan
    Theme --> Type : menggunakan
