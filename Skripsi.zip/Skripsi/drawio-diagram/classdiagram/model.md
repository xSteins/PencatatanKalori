---
config:
  layout: dagre
  theme: redux
---
classDiagram
direction TB
    class UserData {
	    +String id
	    +Int age
	    +String gender
	    +Float weight
	    +Float height
	    +ActivityLevel activityLevel
	    +GoalType goalType
	    +Int dailyCalorieTarget
    }
    class DailyData {
	    +String id
	    +String userId
	    +Date date
	    +Int tdee
	    +Int granularityValue
	    +CalorieStrategy calorieStrategy
	    +Boolean advancedEnabled
	    +GoalType goalType
    }
    class ActivityLog {
	    +String id
	    +String userId
	    +String dailyDataId
	    +ActivityType type
	    +Date timestamp
	    +String name
	    +Int calories
	    +String pictureUri
    }
    class ActivityType {
	    WORKOUT
	    CONSUMPTION
    }
    class ActivityLevel {
	    SEDENTARY
	    LIGHTLY_ACTIVE
	    MODERATELY_ACTIVE
	    VERY_ACTIVE
	    +Double multiplier
	    +getDisplayName() String
    }
    class GoalType {
	    LOSE_WEIGHT
	    GAIN_WEIGHT
	    +getDisplayName() String
	    +getShortDisplayName() String
    }
    class CalorieStrategy {
	    CONSERVATIVE
	    MODERATE
	    AGGRESSIVE
	    +getDisplayName() String
    }
    class UserDataDao {
	    +getUserData() Flow~UserData~
	    +getUserById(String) UserData
	    +insertUserData(UserData)
	    +updateUserData(UserData)
	    +deleteUserData(UserData)
	    +getUserDataCount() Int
    }
    class DailyDataDao {
	    +getDailyDataByUserIdAndDate(String, Date) Flow~DailyData~
	    +insertDailyData(DailyData)
	    +updateDailyData(DailyData)
	    +deleteDailyData(DailyData)
    }
    class ActivityLogDao {
	    +getActivitiesByUserIdAndDate(String, Date) Flow~List~ActivityLog~~
	    +insertActivity(ActivityLog)
	    +updateActivity(ActivityLog)
	    +deleteActivity(ActivityLog)
    }
    class CalorieRepository {
	    -UserDataDao userDataDao
	    -ActivityLogDao activityLogDao
	    -DailyDataDao dailyDataDao
	    -MutableStateFlow isDummyDataEnabled
	    +getUserProfile() Flow~UserData~
	    +getUserProfileOnce() UserData
	    +getTodayActivities() Flow~List~ActivityLog~~
	    +getTodayDailyDataFlow() Flow~DailyData~
	    +createActivity(ActivityLog)
	    +updateActivity(ActivityLog)
	    +deleteActivity(ActivityLog)
    }
    class MifflinModel {
	    +calculateRMR(Double, Double, Int, Boolean) Double
	    +calculateTDEE(UserData) Double
	    +calculateRemainingCalories(UserData, Int, Int, DailyData) Int
	    +adjustTargetCalorie(Int)
	    +setCalorieStrategy(CalorieStrategy)
	    +setAdvancedEnabled(Boolean)
    }
    class AppDatabase {
	    +userDataDao() UserDataDao
	    +dailyDataDao() DailyDataDao
	    +activityLogDao() ActivityLogDao
    }
    class Converters {
	    +fromActivityLevel(ActivityLevel) String
	    +toActivityLevel(String) ActivityLevel
	    +fromGoalType(GoalType) String
	    +toGoalType(String) GoalType
	    +fromDate(Date) Long
	    +toDate(Long) Date
	    +fromActivityType(ActivityType) String
	    +toActivityType(String) ActivityType
	    +fromCalorieStrategy(CalorieStrategy) String
	    +toCalorieStrategy(String) CalorieStrategy
    }
    class DatabaseModule {
	    +provideDatabase(Application) AppDatabase
	    +provideUserDataDao(AppDatabase) UserDataDao
	    +provideDailyDataDao(AppDatabase) DailyDataDao
	    +provideActivityLogDao(AppDatabase) ActivityLogDao
    }
    class UntitledClass {
    }
	<<Enum>> ActivityType
	<<Enum>> ActivityLevel
	<<Enum>> GoalType
	<<Enum>> CalorieStrategy
	<<interface>> UserDataDao
	<<interface>> DailyDataDao
	<<interface>> ActivityLogDao
	<<singleton>> MifflinModel
	<<abstract>> AppDatabase
	<<module>> DatabaseModule
    UserData --> DailyData : punya banyak
    DailyData --> ActivityLog : mencatat banyak
    UserData --> ActivityLevel
    UserData --> GoalType
    DailyData --> GoalType
    DailyData --> CalorieStrategy
    ActivityLog --> ActivityType
    AppDatabase --> UserDataDao
    AppDatabase --> DailyDataDao
    AppDatabase --> ActivityLogDao
    CalorieRepository --> UserDataDao
    CalorieRepository --> DailyDataDao
    CalorieRepository --> ActivityLogDao
    CalorieRepository --> MifflinModel
    DatabaseModule --> AppDatabase
    DatabaseModule --> UserDataDao
    DatabaseModule --> DailyDataDao
    DatabaseModule --> ActivityLogDao
    AppDatabase --> Converters
