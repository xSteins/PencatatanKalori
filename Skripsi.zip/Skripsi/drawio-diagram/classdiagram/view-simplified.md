---
config:
  layout: elk
---
classDiagram
    class OverviewScreen {
        <<Composable>>
        +OverviewScreen()
        -CircularProgressCard(Composable)
        -CalorieInfoCard(Composable)
        -TodayActivityCard(Composable)
        -RemainingCalorieCard(Composable)
    }

    class History {
        <<Composable>>
        +History()
        -ActivityHistoryCard(Composable)
        -DatePickerComponent(Composable)
    }

    class ProfileSettings {
        <<Composable>>
        +ProfileSettings()
        -UserProfileCard(Composable)
        -CalorieSettingsCard(Composable)
        -DebugOptionsCard(Composable)
    }

    class AddOrEditLogModal {
        <<Composable>>
        +AddOrEditLogModal()
    }

    class CalorieSettingsDialog {
        <<Composable>>
        +CalorieSettingsDialog()
    }

    class LogsDetailedModal {
        <<Composable>>
        +LogsDetailedModal()
    }

    class EditUserDataDialog {
        <<Composable>>
        +EditUserDataDialog()
    }

    class UserDataDebugDialog {
        <<Composable>>
        +UserDataDebugDialog()
    }

    class PhysicalInfoText {
        <<Composable>>
        +PhysicalInfoText()
    }

    class CreateNewActivityDate {
        <<Composable>>
        +CreateNewActivityDate()
    }

    OverviewScreen --> AddOrEditLogModal : menggunakan
    OverviewScreen --> CalorieSettingsDialog : menggunakan
    OverviewScreen --> LogsDetailedModal : menggunakan

    History --> AddOrEditLogModal : menggunakan
    History --> LogsDetailedModal : menggunakan

    ProfileSettings --> EditUserDataDialog : menggunakan
    ProfileSettings --> CalorieSettingsDialog : menggunakan
    ProfileSettings --> UserDataDebugDialog : menggunakan
    ProfileSettings --> PhysicalInfoText : menggunakan
    ProfileSettings --> CreateNewActivityDate : menggunakan
