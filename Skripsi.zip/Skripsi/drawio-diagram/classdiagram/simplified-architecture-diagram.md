classDiagram
    class OverviewFeature {
        <<Feature Module>>
        +Display daily calorie progress
        +Show today's activities
        +Calculate remaining calories
        +Add/edit activity logs
        +Real-time calorie tracking
    }

    class OverviewScreen {
        <<UI Layer>>
        +Progress indicators
        +Activity cards
        +FAB for adding logs
        +Calorie information display
    }

    class OverviewViewModel {
        <<Presentation Layer>>
        +Combine user profile data
        +Calculate daily progress
        +Manage activity operations
        +Real-time data updates
    }

    class HistoryFeature {
        <<Feature Module>>
        +View historical data
        +Filter by date range
        +Analyze calorie trends
        +Manage past activities
        +Generate insights
    }

    class HistoryScreen {
        <<UI Layer>>
        +Date range picker
        +Historical activity list
        +Progress charts
        +Filter controls
    }

    class HistoryViewModel {
        <<Presentation Layer>>
        +Manage date range filtering
        +Aggregate historical data
        +Calculate trends
        +Handle bulk operations
    }

    class ProfileSettingsFeature {
        <<Feature Module>>
        +Manage user profile
        +Configure calorie settings
        +Adjust calculation parameters
        +Debug operations
        +App preferences
    }

    class ProfileSettingsScreen {
        <<UI Layer>>
        +User info editor
        +Calorie strategy selector
        +Advanced settings toggle
        +Debug controls
    }

    class ProfileViewModel {
        <<Presentation Layer>>
        +Manage user data updates
        +Handle calorie configurations
        +Coordinate settings changes
        +Provide debug capabilities
    }

    class CalorieRepository {
        <<Data Layer>>
        +Centralized data access
        +User profile management
        +Activity log operations
        +Daily data coordination
        +Flow-based data streams
    }

    class DatabaseLayer {
        <<Data Storage>>
        +UserData entity
        +DailyData entity  
        +ActivityLog entity
        +Room Database
        +Type converters
    }

    class CalculationEngine {
        <<Business Logic>>
        +Mifflin-St Jeor formula
        +TDEE calculations
        +Calorie strategies
        +Activity level factors
        +Goal-based adjustments
    }

    OverviewFeature --> OverviewScreen
    OverviewFeature --> OverviewViewModel
    OverviewScreen --> OverviewViewModel : mengamati

    HistoryFeature --> HistoryScreen  
    HistoryFeature --> HistoryViewModel
    HistoryScreen --> HistoryViewModel : mengamati

    ProfileSettingsFeature --> ProfileSettingsScreen
    ProfileSettingsFeature --> ProfileViewModel  
    ProfileSettingsScreen --> ProfileViewModel : mengamati

    OverviewViewModel --> CalorieRepository : menggunakan
    HistoryViewModel --> CalorieRepository : menggunakan
    ProfileViewModel --> CalorieRepository : menggunakan

    CalorieRepository --> DatabaseLayer : mengakses
    CalorieRepository --> CalculationEngine : menggunakan

    OverviewViewModel --> CalculationEngine : menggunakan
    HistoryViewModel --> CalculationEngine : menggunakan

    OverviewFeature --> ProfileSettingsFeature : menggunakan pengaturan
    HistoryFeature --> ProfileSettingsFeature : menggunakan profil
    OverviewFeature --> HistoryFeature : menyumbang data

    DatabaseLayer --> CalorieRepository : aliran data
    CalorieRepository --> OverviewViewModel : StateFlow
    CalorieRepository --> HistoryViewModel : StateFlow  
    CalorieRepository --> ProfileViewModel : StateFlow
    OverviewViewModel --> OverviewScreen : UI State
    HistoryViewModel --> HistoryScreen : UI State
    ProfileViewModel --> ProfileSettingsScreen : UI State
