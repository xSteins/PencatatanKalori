classDiagram
    class OverviewViewModel {
        <<@HiltViewModel>>
        - CalorieRepository repository
        - MutableStateFlow~OverviewUiState~ _uiState
        + StateFlow~OverviewUiState~ uiState
        + StateFlow~UserData~ userProfile
        + StateFlow~List~ActivityLog~~ todayActivities
        + StateFlow~OverviewData~ overviewData
        + createActivity(ActivityLog)
        + updateActivity(ActivityLog)
        + deleteActivity(ActivityLog)
        + refreshData()
    }

    class HistoryViewModel {
        <<@HiltViewModel>>
        - CalorieRepository repository
        - MutableStateFlow~HistoryUiState~ _uiState
        + StateFlow~HistoryUiState~ uiState
        - MutableStateFlow~Pair~Date, Date~~ _dateRange
        + StateFlow~Pair~Date, Date~~ dateRange
        + StateFlow~List~DailyData~~ dailyDataList
        + StateFlow~List~ActivityLog~~ activitiesInRange
        + updateDateRange(Date, Date)
        + createActivity(ActivityLog)
        + updateActivity(ActivityLog)
        + deleteActivity(ActivityLog)
        + getActivitiesForDate(Date) List~ActivityLog~
        + calculateDailyCalories(Date) Pair~Int, Int~
    }

    class ProfileViewModel {
        <<@HiltViewModel>>
        - CalorieRepository repository
        - MutableStateFlow~ProfileUiState~ _uiState
        + StateFlow~ProfileUiState~ uiState
        + StateFlow~UserData~ userProfile
        + StateFlow~DailyData~ todayDailyData
        + updateUserProfile(UserData)
        + updateCalorieSettings(CalorieStrategy, Int, Boolean)
        + createNewActivityDate(Date)
        + deleteAllData()
        + resetToDefaults()
    }

    class OnboardingViewModel {
        <<@HiltViewModel>>
        - CalorieRepository repository
        - MutableStateFlow~OnboardingUiState~ _uiState
        + StateFlow~OnboardingUiState~ uiState
        + createUserData(Int, String, Float, Float, ActivityLevel, GoalType, Int)
        + checkIfUserExists() Boolean
        + completeOnboarding()
    }

    class UserDataDebugViewModel {
        <<@HiltViewModel>>
        - UserDataDao userDataDao
        - ActivityLogDao activityLogDao
        - MutableStateFlow~UserDataDebugUiState~ _uiState
        + StateFlow~UserDataDebugUiState~ uiState
        + refreshDebugData()
        + clearAllData()
        + insertDummyData()
        + exportData() String
    }

    class OverviewUiState {
        <<sealed class>>
        + Loading
        + Success
        + Error
    }

    class HistoryUiState {
        <<sealed class>>
        + Loading
        + Success
        + Error
    }

    class ProfileUiState {
        <<sealed class>>
        + Loading
        + Success
        + Error
    }

    class OnboardingUiState {
        <<sealed class>>
        + Initial
        + Loading
        + Success
        + Error
    }

    class UserDataDebugUiState {
        <<sealed class>>
        + Loading
        + Success~DebugData~
        + Error
    }

    class OverviewData {
        + UserData userData
        + Int kaloriDikonsumsi
        + Int kaloriTerbakar
        + Int kaloriTersisa
        + Int targetKalori
        + List~ActivityLog~ aktivitasHariIni
        + DailyData dataHarian
    }

    class DebugData {
        + UserData userData
        + List~ActivityLog~ daftarAktivitas
        + Int totalAktivitas
        + Int totalKonsumsi
        + Int totalOlahraga
        + Int totalKaloriMasuk
        + Int totalKaloriKeluar
    }

    class MifflinModel {
        <<singleton>>
        - Int granularityValue
        - CalorieStrategy calorieStrategy
        - Boolean isAdvancedEnabled
        + calculateRMR(Double, Double, Int, Boolean) Double
        + adjustTargetCalorie(Int)
        + getGranularityValue() Int
        + setCalorieStrategy(CalorieStrategy)
        + getCalorieStrategy() CalorieStrategy
        + setAdvancedEnabled(Boolean)
        + isAdvancedEnabled() Boolean
        + calculateDailyCaloriesTarget(Double, ActivityLevel, GoalType, Int) Double
        + calculateDailyCalories(Float, Float, Int, Boolean, ActivityLevel, GoalType, Int) Int
        + calculateRemainingCalories(Int, Int, Int, GoalType, Boolean, CalorieStrategy) Int
        + calculateRemainingCalories(Int, Int, Int, GoalType) Int
        + calculateNetCalories(Int, Int, GoalType, Boolean, CalorieStrategy) Int
        + calculateNetCalories(Int, Int, GoalType) Int
        + getCalorieAdjustmentExplanation(GoalType, Double, Double, Int, Boolean, ActivityLevel, Int, CalorieStrategy, Boolean) String
        + getCalorieAdjustmentExplanation(GoalType, Double, Double, Int, Boolean, ActivityLevel) String
        + getExerciseCaloriePercentage(GoalType) Double
        + getCurrentStrategy() CalorieStrategy
    }

    class CalorieStrategy {
        <<enumeration>>
        + CONSERVATIVE
        + MODERATE  
        + AGGRESSIVE
        + getDisplayName() String
        + getExerciseCalorieExplanation(GoalType, Double, Double, Int, Boolean) String
    }

    class ActivityLevel {
        <<enumeration>>
        + SEDENTARY
        + LIGHTLY_ACTIVE
        + MODERATELY_ACTIVE
        + VERY_ACTIVE
        + Double multiplier
        + getDisplayName() String
    }

    class GoalType {
        <<enumeration>>
        + LOSE_WEIGHT
        + GAIN_WEIGHT
        + getDisplayName() String
        + getShortDisplayName() String
    }

    class CalorieRepository {
        <<@Singleton>>
        - UserDataDao userDataDao
        - ActivityLogDao activityLogDao
        - DailyDataDao dailyDataDao
        + getUserProfile() Flow~UserData~
        + getUserProfileOnce() UserData
        + getTodayActivities() Flow~List~ActivityLog~~
        + getTodayDailyDataFlow() Flow~DailyData~
        + createActivity(ActivityLog)
        + updateActivity(ActivityLog)
        + deleteActivity(ActivityLog)
        + createOrUpdateDailyData(DailyData)
    }

    class UserData {
        + String id
        + Int age
        + String gender
        + Float weight
        + Float height
        + ActivityLevel activityLevel
        + GoalType goalType
        + Int dailyCalorieTarget
    }

    class ActivityLog {
        + String id
        + String userId
        + String dailyDataId
        + ActivityType type
        + Date timestamp
        + String name
        + Int calories
        + String pictureUri
    }

    class DailyData {
        + String id
        + String userId
        + Date date
        + Int tdee
        + Int granularityValue
        + CalorieStrategy calorieStrategy
        + Boolean advancedEnabled
        + GoalType goalType
    }

    %% --- Relasi ViewModel dan Repository ---
    OverviewViewModel --> CalorieRepository : menggunakan
    HistoryViewModel --> CalorieRepository : menggunakan
    ProfileViewModel --> CalorieRepository : menggunakan
    OnboardingViewModel --> CalorieRepository : menggunakan
    UserDataDebugViewModel --> UserDataDao : menggunakan
    UserDataDebugViewModel --> ActivityLogDao : menggunakan

    %% --- Relasi ViewModel dan UI State ---
    OverviewViewModel --> OverviewUiState : mengelola
    HistoryViewModel --> HistoryUiState : mengelola
    ProfileViewModel --> ProfileUiState : mengelola
    OnboardingViewModel --> OnboardingUiState : mengelola
    UserDataDebugViewModel --> UserDataDebugUiState : mengelola

    %% --- Relasi Data ---
    OverviewViewModel --> OverviewData : menampilkan
    UserDataDebugViewModel --> DebugData : menampilkan

    %% --- Relasi Observasi ---
    OverviewViewModel ..> UserData : mengamati
    OverviewViewModel ..> ActivityLog : mengamati
    OverviewViewModel ..> DailyData : mengamati

    HistoryViewModel ..> UserData : mengamati
    HistoryViewModel ..> ActivityLog : mengamati
    HistoryViewModel ..> DailyData : mengamati

    ProfileViewModel ..> UserData : mengamati
    ProfileViewModel ..> DailyData : mengamati

    %% --- Logika Bisnis ---
    OverviewViewModel --> MifflinModel : menggunakan perhitungan
    HistoryViewModel --> MifflinModel : menggunakan perhitungan
    ProfileViewModel --> MifflinModel : menggunakan perhitungan
    OnboardingViewModel --> MifflinModel : menggunakan perhitungan
    
    %% --- Relasi MifflinModel ---
    MifflinModel --> CalorieStrategy : menggunakan
    MifflinModel --> ActivityLevel : menggunakan
    MifflinModel --> GoalType : menggunakan
    
    %% --- Pengaturan Profil ---
    ProfileViewModel ..> CalorieStrategy : mengatur strategi
    ProfileViewModel ..> ActivityLevel : mengatur level aktivitas  
    ProfileViewModel ..> GoalType : mengatur tujuan
