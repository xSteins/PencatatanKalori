# State Diagrams - Pencatatan Kalori App

## 1. State Diagram: Proses Onboarding (UserData belum ada / belum melakukan onboarding)

```mermaid
stateDiagram-v2
    [*] --> AppStart
    
    AppStart --> CheckUserProfile : Peluncuran Aplikasi
    
    CheckUserProfile --> HasProfile : checkUserExists() == true
    CheckUserProfile --> NoProfile : checkUserExists() == false
    
    HasProfile --> OverviewScreen : Navigasi ke Overview
    NoProfile --> ShowOnboardingDialog : Tampilkan dialog otomatis
    
    ShowOnboardingDialog --> InputValidation : Pengguna mengisi form
    
    state InputValidation {
        [*] --> ValidatingInputs
        ValidatingInputs --> InvalidAge : age.isBlank() || age.toInt() <= 0
        ValidatingInputs --> InvalidWeight : weight.isBlank() || weight.toFloat() <= 0
        ValidatingInputs --> InvalidHeight : height.isBlank() || height.toFloat() <= 0
        ValidatingInputs --> MissingActivityLevel : selectedActivityLevel == null
        ValidatingInputs --> MissingGoalType : selectedGoalType == null
        ValidatingInputs --> AllValid : Semua field valid
        
        InvalidAge --> ShowError
        InvalidWeight --> ShowError
        InvalidHeight --> ShowError
        MissingActivityLevel --> ShowError
        MissingGoalType --> ShowError
        ShowError --> ValidatingInputs : Pengguna memperbaiki input
    }
    
    AllValid --> SaveButtonEnabled : isValid = true
    SaveButtonEnabled --> SubmitData : Pengguna klik Simpan
    
    SubmitData --> OnboardingLoading : _uiState = Loading
    
    OnboardingLoading --> CalculateCalories : MifflinModel.calculateDailyCalories()
    CalculateCalories --> CreateUserData : UserData entity creation
    CreateUserData --> SaveToDatabase : repository.createUser()
    
    SaveToDatabase --> OnboardingSuccess : Berhasil
    SaveToDatabase --> OnboardingError : Error database
    
    OnboardingSuccess --> CloseDialog : _uiState = Success
    OnboardingError --> ShowErrorMessage : _uiState = Error(message)
    
    ShowErrorMessage --> InputValidation : Pengguna coba lagi
    
    CloseDialog --> OverviewScreen : Navigasi selesai
    OverviewScreen --> [*]
    
    note right of CheckUserProfile
        Dilakukan di ProfileSettings screen
        dengan LaunchedEffect(Unit)
    end note
    
    note right of InputValidation
        Validasi waktu nyata:
        - Age: integer > 0
        - Weight: float > 0
        - Height: float > 0
        - ActivityLevel: tidak null
        - GoalType: tidak null
    end note
    
    note right of CalculateCalories
        Menggunakan Mifflin-St Jeor equation
        berdasarkan gender, age, weight, height,
        activityLevel, dan goalType
    end note
```

## 2. State Diagram: Validasi Input Ketika Menambahkan Data Aktivitas (Konsumsi/Olahraga)

```mermaid
stateDiagram-v2
    [*] --> ActivityModalClosed
    
    ActivityModalClosed --> OpenModal : Pengguna klik Tambah Food/Workout
    
    OpenModal --> InitializeForm : Set modalType (FOOD/WORKOUT)
    
    state InitializeForm {
        [*] --> EmptyForm
        EmptyForm --> EditMode : editData != null
        EmptyForm --> CreateMode : editData == null
        
        EditMode --> LoadExistingData : Muat data existing
        CreateMode --> BlankForm : Kosongkan semua field
        
        LoadExistingData --> FormReady
        BlankForm --> FormReady
    }
    
    FormReady --> InputProcessing : Pengguna ketik input
    
    state InputProcessing {
        [*] --> ValidatingName
        
        state ValidatingName {
            [*] --> CheckNameEmpty
            CheckNameEmpty --> NameEmpty : name.isBlank()
            CheckNameEmpty --> CheckNameLength : name tidak kosong
            CheckNameLength --> NameTooShort : name.trim().length < 3
            CheckNameLength --> NameValid : name.length >= 3
            
            NameEmpty --> SetNameError : nameError = "Name cannot be empty"
            NameTooShort --> SetNameError : nameError = "Name must be at least 3 characters"
            NameValid --> ClearNameError : nameError = null
            
            SetNameError --> [*]
            ClearNameError --> [*]
        }
        
        ValidatingName --> ValidatingCalories
        
        state ValidatingCalories {
            [*] --> CheckCaloriesEmpty
            CheckCaloriesEmpty --> CaloriesEmpty : calories.isBlank()
            CheckCaloriesEmpty --> CheckCaloriesNumber : calories tidak kosong
            CheckCaloriesNumber --> InvalidNumber : toIntOrNull() == null
            CheckCaloriesNumber --> CheckCaloriesPositive : angka valid
            CheckCaloriesPositive --> CaloriesZeroOrNegative : calories.toInt() <= 0
            CheckCaloriesPositive --> CaloriesValid : calories.toInt() > 0
            
            CaloriesEmpty --> SetCaloriesError : caloriesError = "Kalori tidak boleh kosong"
            InvalidNumber --> SetCaloriesError : caloriesError = "Please enter a valid number"
            CaloriesZeroOrNegative --> SetCaloriesError : caloriesError = "Kalori harus lebih besar dari 0"
            CaloriesValid --> ClearCaloriesError : caloriesError = null
            
            SetCaloriesError --> [*]
            ClearCaloriesError --> [*]
        }
        
        ValidatingCalories --> FormValidationComplete
    }
    
    FormValidationComplete --> CheckOverallValidation : isFormValid()
    
    CheckOverallValidation --> FormInvalid : nameError != null || caloriesError != null
    CheckOverallValidation --> FormValid : kedua validasi lulus
    
    FormInvalid --> ShowValidationErrors : Tampilkan pesan error
    ShowValidationErrors --> InputProcessing : Pengguna lanjut edit
    
    FormValid --> EnableSubmitButton : Tombol Submit aktif
    EnableSubmitButton --> AwaitUserAction : Tunggu aksi pengguna
    
    AwaitUserAction --> SubmitForm : Pengguna klik Simpan
    AwaitUserAction --> CancelForm : Pengguna klik Batal
    AwaitUserAction --> DeleteActivity : Pengguna klik Hapus (mode edit)
    AwaitUserAction --> InputProcessing : Pengguna lanjut edit
    
    SubmitForm --> ProcessImageUpload : Cek perubahan gambar
    
    state ProcessImageUpload {
        [*] --> CheckImageChange
        CheckImageChange --> NoImageChange : imagePath == initialImagePath
        CheckImageChange --> ImageChanged : imagePath != initialImagePath
        CheckImageChange --> NewImage : imagePath != null && editData == null
        
        NoImageChange --> DirectSave
        ImageChanged --> SaveNewImage : viewModel.savePicture()
        NewImage --> SaveNewImage
        
        SaveNewImage --> ImageSaveSuccess : onSuccess callback
        SaveNewImage --> ImageSaveError : onError callback
        
        ImageSaveSuccess --> SaveWithPictureId : Update dengan pictureId baru
        ImageSaveError --> SaveWithoutPicture : Gunakan pictureId existing/null
        DirectSave --> SaveActivity
        SaveWithPictureId --> SaveActivity
        SaveWithoutPicture --> SaveActivity
    }
    
    SaveActivity --> UpdateDatabase : Buat/Update ActivityLog
    
    UpdateDatabase --> CreateNewActivity : editData == null
    UpdateDatabase --> UpdateExistingActivity : editData != null
    
    CreateNewActivity --> LogNewActivity : viewModel.logActivity()
    UpdateExistingActivity --> UpdateActivity : viewModel.updateActivity()
    
    LogNewActivity --> DatabaseSuccess
    UpdateActivity --> DatabaseSuccess
    
    DatabaseSuccess --> CloseModal : showLogModal = false
    
    CancelForm --> CloseModal
    DeleteActivity --> DeleteFromDatabase : viewModel.deleteActivity()
    DeleteFromDatabase --> CloseModal
    
    CloseModal --> ActivityModalClosed
    ActivityModalClosed --> [*]
    
    note right of ValidatingName
        Validasi waktu nyata saat pengguna mengetik:
        - Tidak boleh kosong
        - Minimal 3 karakter setelah trim
        - Pesan error ditampilkan di bawah field
    end note
    
    note right of ValidatingCalories
        Validasi waktu nyata untuk input kalori:
        - Tidak boleh kosong
        - Harus berupa angka valid
        - Harus lebih besar dari 0
        - Menggunakan KeyboardType.Number
    end note
    
    note right of ProcessImageUpload
        Proses unggah gambar:
        - Jika ada perubahan gambar, simpan ke internal storage
        - Generate UUID untuk nama file
        - Return pictureId untuk disimpan di database
        - Fallback ke existing/null jika gagal
    end note
```

## Penjelasan State Diagrams

### 1. Proses Onboarding

Diagram pertama menunjukkan alur lengkap proses onboarding untuk pengguna baru:

- **Peluncuran Aplikasi**: Aplikasi dimulai dan melakukan pengecekan profil pengguna
- **Pemeriksaan Profil**: Menggunakan `profileViewModel.checkUserExists()` untuk menentukan apakah pengguna sudah ada
- **Dialog Otomatis**: Jika pengguna belum ada, dialog onboarding otomatis ditampilkan
- **Validasi Input**: Validasi waktu nyata untuk semua field yang diperlukan
- **Kalkulasi Kalori**: Menggunakan Mifflin-St Jeor equation untuk menghitung kebutuhan kalori harian
- **Penyimpanan Database**: Menyimpan UserData ke Room database
- **Navigasi**: Setelah berhasil, pengguna diarahkan ke OverviewScreen

### 2. Validasi Input Aktivitas

Diagram kedua menunjukkan proses validasi dan penyimpanan data aktivitas:

- **Manajemen Modal**: Membuka/menutup AddOrEditLogModal berdasarkan aksi pengguna
- **Validasi Input**: Validasi waktu nyata untuk nama dan kalori dengan penanganan error
- **Pemrosesan Gambar**: Menangani unggah dan penyimpanan gambar ke internal storage
- **Operasi Database**: Operasi Create/Update/Delete pada ActivityLog entity
- **Sinkronisasi State**: Menjaga konsistensi state antara UI dan database


```mermaid
---
config:
  layout: elk
---
stateDiagram
  direction TB
  [*] --> AplikasiDibuka
  AplikasiDibuka --> CekUserData
  CekUserData --> UserDataDitemukan:Data ditemukan
  CekUserData --> UserDataTidakDitemukan:Data tidak ditemukan
  UserDataDitemukan --> TampilanAktif:Tampilan bisa digunakan
  UserDataTidakDitemukan --> TampilkanOnboarding:Navigasi ke ProfileSettings + Dialog
  TampilkanOnboarding --> UserIsiData
  UserIsiData --> DataValid:Input benar
  UserIsiData --> DataTidakValid:Input salah
  DataValid --> SimpanData
  SimpanData --> TampilanAktif:Tampilan bisa digunakan
  DataTidakValid --> TampilanNonaktif:Tampilan tidak bisa digunakan
  TampilanNonaktif --> UserIsiData:User perbaiki input
  TampilanAktif --> [*]

```

```mermaid
---
config:
  layout: dagre
---
stateDiagram
  direction TB
  [*] --> UserKlikTambahDataAktivitas
  UserKlikTambahDataAktivitas --> BukaModal
  BukaModal --> UserIsiForm
  UserIsiForm --> ValidasiInput
  ValidasiInput --> InputValid:Nama + Kalori OK
  ValidasiInput --> InputTidakValid:Ada yang salah
  InputValid --> SimpanData:Tombol Simpan bisa diklik
  InputTidakValid --> TombolTidakAktif:Tombol Simpan tidak bisa diklik
  TombolTidakAktif --> UserIsiForm:User perbaiki input
  SimpanData --> TutupModal:Data tersimpan
  Gagal --> TampilkanError
  TampilkanError --> UserIsiForm:User coba lagi
  TutupModal --> [*]

```
